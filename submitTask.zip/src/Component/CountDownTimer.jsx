import { Avatar, Card } from '@mui/material'
import React, { useState } from 'react'
import CloseIcon from '@mui/icons-material/Close';
function CountDownTimer({seconds}) {
const [close , setClose]=useState(false)

const clickClose=()=>{
    setClose(false)
}

  return (
    <div>
        <Card sx={{backgroundColor:"green", padding:"10px" , width:"100px" , mb:"20px"}}>
     
  {seconds}
     <Avatar sx={{ position: 'absolute', top: '10px', right: '5px',p:'2px',width: 20, height: 20 , color:"black" , backgroundColor:"white"}} > 
     <CloseIcon onClick={clickClose}/> 
      </Avatar>
  
  </Card>    
    </div>
  )
}

export default CountDownTimer