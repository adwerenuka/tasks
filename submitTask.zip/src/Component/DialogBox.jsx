import { Avatar, Box, Button, TextField, Typography } from '@mui/material';
import React, { useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';

function DialogBox({ handleClickClose }) {
  const [num, setNum] = useState('');
  const [number, setNumber] = useState('');

  const clickNum = () => {
    const parsedNum = parseFloat(num);

    if (isNaN(parsedNum) || !Number.isFinite(parsedNum)) {
    
      setNumber('Please enter a valid number');
    } else {
    
      setNumber('');
      handleClickClose();
    }
  };

  return (
    <Box sx={{ width: '400px' }}>
      <Avatar sx={{ position: 'absolute', top: '30px', right: '38px', p: '2px', width: 20, height: 20 , color:"black", backgroundColor:"white"}}>
        <CloseIcon onClick={handleClickClose} />
      </Avatar>
      <Box sx={{ display: 'flex' }} p={3} mt={7}>
        <Typography>SetTimeOut:</Typography>
        <TextField type="text" value={num} onChange={(e) => setNum(e.target.value)}  sx={{ml:"20px"}} size='small'/>
        {number && <Typography color="error">{number}</Typography>}
      </Box>
      <Box sx={{mb:"20px"}}>
      <Button variant="contained" onClick={clickNum} sx={{ left: '40%',     backgroundColor: "#beb", textTransform: "capitalize", color: "black", '&:hover': {
                    backgroundColor: "#beb", 
                } }}>
        Confirm
      </Button>


      </Box>

    </Box>
  );
}

export default DialogBox;
