import { Box } from '@mui/material'
import React from 'react'

function Footer1() {
  return (
    <div>
        <Box sx={{backgroundColor:"gray", height:"50px" }}>
          Footer
        </Box>
    </div>
  )
}

export default Footer1