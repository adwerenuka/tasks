import { Box, Card, Typography ,Grid} from '@mui/material';
import { css } from '@emotion/react';
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';

function Header() {
    const location = useLocation();

    const navLinkStyle = css({
        textDecoration: 'none',
        color: 'black', // Set the default color
        '&:hover': {
            color: 'blue', // Set the hover color
        },
    });

    return (
        <div>
            <Card sx={{ backgroundColor: 'pink', height: '50px' }} component={Box} square>
                <Grid container>
                    <Grid item xs={6} >
                    <Typography variant='h5' sx={{float:"left" , ml:"30px" , pt:"10px"}}>Header</Typography>
                    </Grid>
                    <Grid item xs={6}>
                    <Box sx={{ display: 'flex', float: 'right', my: '10px' }}>
                    <Card>
                        <NavLink to="/" style={location.pathname === '/' ? { color: 'red' } : {}} css={navLinkStyle}>
                            <Typography variant="body1">Component1</Typography>
                        </NavLink>
                    </Card>
                    <Card sx={{ ml: '20px' }}>
                        <NavLink to="/comp" style={location.pathname === '/comp' ? { color: 'red' } : {}} css={navLinkStyle}>
                            <Typography variant="body1">Component2</Typography>
                        </NavLink>
                    </Card>
                    <Card sx={{ ml: '20px' }}>
                        <NavLink to="/comp3" style={location.pathname === '/comp3' ? { color: 'red' } : {}} css={navLinkStyle}>
                            <Typography variant="body1">Component3</Typography>
                        </NavLink>
                    </Card>
                </Box>
                    </Grid>
                </Grid>
            

            </Card>
        </div>
    );
}

export default Header;
